# D7s-Style
#For Install in Linux and Termux:
#     pip3 install D7s-Style
